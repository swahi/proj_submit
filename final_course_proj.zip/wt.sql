-- phpMyAdmin SQL Dump
-- version 2.11.5
-- http://www.phpmyadmin.net
--
-- Host: localhost:3306
-- Generation Time: May 07, 2013 at 08:47 PM
-- Server version: 5.0.15
-- PHP Version: 5.2.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `wt`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `aid` int(11) NOT NULL auto_increment,
  `aname` char(20) default NULL,
  `ausername` varchar(20) default NULL,
  `apassword` varchar(20) default NULL,
  PRIMARY KEY  (`aid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`aid`, `aname`, `ausername`, `apassword`) VALUES
(1, 'C.D.Kerure', 'bvbcet', 'bvbcet');

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE `company` (
  `cid` int(11) NOT NULL auto_increment,
  `cname` varchar(50) default NULL,
  `email_id` varchar(35) default NULL,
  `comp_description` varchar(5000) default NULL,
  PRIMARY KEY  (`cid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`cid`, `cname`, `email_id`, `comp_description`) VALUES
(3, 'Accenture', 'acc@accenture.com', 'Accenture plc is a multinational management consulting, technology services and outsourcing company headquartered in Dublin, Republic of Ireland. It is the world''s largest consulting firm measured by revenues and is a constituent of the Fortune Global 500 list.As of September 2011, the company had more than 244,000 employees across 120 countries.Accenture''s current clients include 96 of the Fortune Global 100 and more than three-quarters of the Fortune Global 500. The international company was first incorporated in Bermuda in 2001. Since September 1, 2009 the company has been incorporated in Ireland.'),
(4, 'Akamai', 'aka@akamai.com', 'Akamai Technologies, a company that develops software for web content and application delivery Akamai Foundation, a sponsor of the American Mathematics Competitions, founded by Akamai Technologies.'),
(5, 'Informatica', 'info@informatica.com', 'hello'),
(6, 'infosys', 'infi@infosys.com', 'Infosys Limited, formerly Infosys Technologies Limited, is an Indian multinational provider of business consulting, technology, engineering, and outsourcing services. It is headquartered in Bangalore, Karnataka. Infosys was co-founded in 1981 by N. R. Narayana Murthy, Nandan Nilekani, N. S. Raghavan, S. Gopalakrishnan, S. D. Shibulal, K. Dinesh and Ashok Arora after they resigned from Patni Computer Systems.'),
(7, 'Mindtree', 'mind@mindtree.com', 'Mindtree Limited, formerly known as Mindtree Consulting Limited, is a mid-sized international information technology (IT) consulting and implementation company. It operates in two units: Product engineering Services and IT Services. Mindtree was started in 1999 by ten industry professionals from Cambridge Technology Partners, Lucent Technologies, and Wipro.Mindtree was started by seven Indian businessmen in IT –and three American IT professionals – Anjan Lahiri, Scott Staples, and Kamran Ozair. Staples now heads Mindtree''s US operations.  Currently co-headquartered in Warren, New Jersey, and Bangalore, India, it has three development centers in India and 15 offices in Asia, Europe, and the United States.Mindtree is ranked #18 in Indian IT companies and overall #445 in Fortune India 500 list of 2011.It was the First Indian IT firm that went public, and offered an IPO'),
(8, 'Robert Bosch', 'rob@bosch.com', 'Robert Bosch GmbH is a German multinational engineering and electronics company headquartered in Gerlingen, near Stuttgart. It is the world''s largest supplier of automotive components.The company was founded by Robert Bosch in Stuttgart in 1886.   Bosch has more than 350 subsidiaries across over 60 countries and its products are sold in around 150 countries.[3] Bosch employs around 303,000 people and had revenues of approximately €51.4 billion in 2011. In 2010 it invested around €3.8 billion in research and development and applied for over 3,800 patents worldwide.'),
(9, 'sony', 'sony@sonyindia.com', 'Sony Corporation commonly referred to as Sony, is a Japanese multinational conglomerate corporation headquartered in Konan Minato, Tokyo, Japan.It ranked 87th on the 2012 list of Fortune Global 500.Sony is one of the leading manufacturers of electronics products for the consumer and professional markets.   Sony found its beginning in the wake of World War II. In 1946, Masaru Ibuka started an electronics shop in a bomb-damaged department store building in Tokyo. The company had $530 in capital and a total of eight employees.The next year, he was joined by his colleague, Akio Morita, and they founded a company called Tokyo Tsushin Kogyo(Tokyo Telecommunications Engineering Corporation).In 1958 the company name was changed to Sony.'),
(10, 'Tata Consultancy', 'tata@tataconsultancy.com', 'Tata Consultancy Services Limited (TCS) is an Indian multinational information technology (IT) services, business solutions and outsourcing services company headquartered in Mumbai, Maharashtra. TCS is a subsidiary of the Tata Group and is listed on the Bombay Stock Exchange and the National Stock Exchange of India. It is one of India''s most valuable companies and is the largest India-based IT services company by 2012 revenues.  Tata Consultancy Services (TCS) was founded in 1968. Its early contracts included providing punched card services to sister company TISCO (now Tata Steel), working on an Inter-Branch Reconciliation System for the Central Bank of India,[4] and providing bureau services to Unit Trust of India.'),
(11, 'Toshibha', 'tosh@toshibha,com', 'Toshiba Corporation,earlier named Tokyo Shibaura Electric K.K.It is a Japanese multinational electronics, electrical equipment and information technology corporation headquartered in Tokyo, Japan. It is a diversified manufacturer and marketer of electrical products, spanning information and communications equipment and systems, Internet-based solutions and services, electronic components and materials, power systems, industrial and social infrastructure systems, and household appliances.  The merger in 1939 of Shibaura and Tokyo Denki created a new company called Tokyo Shibaura Denki. It was soon nicknamed Toshiba, but it was not until 1978 that the company was officially renamed Toshiba Corporation.');

-- --------------------------------------------------------

--
-- Table structure for table `comp_feedback`
--

CREATE TABLE `comp_feedback` (
  `cid` int(11) default NULL,
  `question1` varchar(100) default NULL,
  `1option` varchar(20) default NULL,
  `question2` varchar(100) default NULL,
  `2option` varchar(20) default NULL,
  `question3` varchar(100) default NULL,
  `3option` varchar(20) default NULL,
  `question4` varchar(100) default NULL,
  `4option` varchar(20) default NULL,
  KEY `cid` (`cid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comp_feedback`
--

INSERT INTO `comp_feedback` (`cid`, `question1`, `1option`, `question2`, `2option`, `question3`, `3option`, `question4`, `4option`) VALUES
(6, 'Degree of technical knowlegde in students', 'Excellent', 'Degree of communication skills in students', 'Good', 'Confidence level in students', 'Excellent', 'How did you feel about the system in the college', 'Good');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `qid` int(10) NOT NULL auto_increment,
  `chapter` varchar(25) default NULL,
  `question` varchar(100) NOT NULL,
  `option1` varchar(20) NOT NULL,
  `option2` varchar(20) NOT NULL,
  `option3` varchar(20) default NULL,
  `option4` varchar(20) default NULL,
  `key_ans` varchar(20) NOT NULL,
  PRIMARY KEY  (`qid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`qid`, `chapter`, `question`, `option1`, `option2`, `option3`, `option4`, `key_ans`) VALUES
(5, 'Web Technology', 'hello', 'h1', 'h2', 'h3', 'h4', 'h1');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `usn` varchar(20) NOT NULL default '',
  `spass` varchar(50) default NULL,
  `sname` varchar(75) default NULL,
  `admission_date` varchar(50) default NULL,
  `rec_status` varchar(10) default NULL,
  `rec_comp_name` varchar(100) default NULL,
  `package` varchar(10) default NULL,
  `rec_year` varchar(20) default NULL,
  PRIMARY KEY  (`usn`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`usn`, `spass`, `sname`, `admission_date`, `rec_status`, `rec_comp_name`, `package`, `rec_year`) VALUES
('  2BV07IS024', '  2BV07IS024', 'Harish Deshpande', '2008', 'yes', 'iGate', '2.7', '2011'),
('  2BV07IS039', '  2BV07IS039', 'Nagaraja V.Hosamani', '2008', 'yes', 'iGate', '2.7', '2011'),
('27594506BG', '27594506BG', 'Sharad S.Kotur', '2008', 'yes', 'Shriram Transport Finance Company', '2.1', '2011'),
('2BV06IS014', '2BV06IS014', 'Bhushan Yavgal', '2008', 'yes', 'Syntel', '3', '2011'),
('2BV06IS049', '2BV06IS049', 'Pakeerappa', '2008', 'yes', 'MindTree', '3.2', '2011'),
('2BV06IS054', '2BV06IS054', 'Sushant Patil', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV07IS002', '2BV07IS002', 'Abhijit Kulkarni', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV07IS003', '2BV07IS003', 'Abhishek Desai', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV07IS004', '2BV07IS004', 'Aditya Chandavarkar', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV07IS005', '2BV07IS005', 'Ambati Sowjanya', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV07IS006', '2BV07IS006', 'Ameena Bee H Hanasi', '2008', 'yes', 'Accenture', '3', '2011'),
('2BV07IS007', '2BV07IS007', 'Amit Kololgi', '2008', 'yes', 'MindTree', '3.2', '2011'),
('2BV07IS008', '2BV07IS008', 'Anand Shekhar', '2008', 'yes', 'Accenture', '3', '2011'),
('2BV07IS009', '2BV07IS009', 'Anil Kumar G', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV07IS011', '2BV07IS011', 'Anoop Kulkarni', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV07IS012', '2BV07IS012', 'Anudeep Gongadi', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV07IS013', '2BV07IS013', 'Anuradha Shiriyannavar', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV07IS014', '2BV07IS014', 'Avinash kumar', '2008', 'yes', 'SLK Software', '1.8', '2011'),
('2BV07IS015', '2BV07IS015', 'Avinash Patil', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV07IS016', '2BV07IS016', 'Mohammed Thaheer', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV07IS017', '2BV07IS017', 'Bhagirathi Bellubbi', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV07IS018', '2BV07IS018', 'Chandrashekhar Badiger', '2008', 'yes', 'Accenture', '3', '2011'),
('2BV07IS019', '2BV07IS019', 'Chetan Anand', '2008', 'yes', 'Accenture', '3', '2011'),
('2BV07IS020', '2BV07IS020', 'Kiran Kumar D', '2008', 'yes', 'Accenture', '3', '2011'),
('2BV07IS021', '2BV07IS021', 'Deepa Bannigidad', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV07IS023', '2BV07IS023', 'Gaurav Shetty', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV07IS028', '2BV07IS028', 'Kanchana Telkar', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV07IS029', '2BV07IS029', 'Kantilal Brijwasi', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV07IS030', '2BV07IS030', 'Karthik Prakash', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV07IS031', '2BV07IS031', 'Kavita Kadlimatti', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV07IS033', '2BV07IS033', 'Kirti Kori', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV07IS034', '2BV07IS034', 'M S Vinay', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV07IS035', '2BV07IS035', 'Madhuri Malager', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV07IS038', '2BV07IS038', 'Megha Dalvi', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV07IS041', '2BV07IS041', 'Nalini Sivashanmugam', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV07IS042', '2BV07IS042', 'Naveen Kamkar', '2008', 'yes', 'Accenture', '3', '2011'),
('2BV07IS043', '2BV07IS043', 'Neeraj Kumar', '2008', 'yes', 'MindTree', '3.2', '2011'),
('2BV07IS044', '2BV07IS044', 'Nikhil Anand', '2008', 'yes', 'Accenture', '3', '2011'),
('2BV07IS045', '2BV07IS045', 'Nimit Kumar', '2008', 'yes', 'SLK Software', '1.8', '2011'),
('2BV07IS046', '2BV07IS046', 'Nisha Halyal', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV07IS047', '2BV07IS047', 'Nishant D. Solomon', '2009', 'yes', 'MindTree', '3.2', '2012'),
('2BV07IS048', '2BV07IS048', 'Nitish Patil', '2008', 'yes', 'iGate', '2.7', '2011'),
('2BV07IS050', '2BV07IS050', 'Paramjeet Singh', '2008', 'yes', 'MindTree', '3.2', '2011'),
('2BV07IS053', '2BV07IS053', 'Poonam H Kalburgi', '2008', 'yes', 'Informatica Business Solutions Pvt. Ltd.', '5.5', '2011'),
('2BV07IS054', '2BV07IS054', 'Pradeep I Baradur', '2008', 'yes', 'Accenture', '3', '2011'),
('2BV07IS055', '2BV07IS055', 'Pradeep KM', '2008', 'yes', 'Accenture', '3', '2011'),
('2BV07IS056', '2BV07IS056', 'Pranob Kumar Jain', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV07IS057', '2BV07IS057', 'Prashanth S Choulagi', '2008', 'yes', 'Accenture', '3', '2011'),
('2BV07IS058', '2BV07IS058', 'Prashanth Kumar', '2008', 'yes', 'Accenture', '3', '2011'),
('2BV07IS059', '2BV07IS059', 'Prashanth N G', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV07IS061', '2BV07IS061', 'Priyadarshini Humberi', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV07IS062', '2BV07IS062', 'Priyanka Nadagoud', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV07IS063', '2BV07IS063', 'Priyanka Patil', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV07IS064', '2BV07IS064', 'Meghana Narayan', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV07IS066', '2BV07IS066', 'Rajesh Sajjan', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV07IS067', '2BV07IS067', 'Rajnish Kumar Dwivedy', '2008', 'yes', 'Accenture', '3', '2011'),
('2BV07IS069', '2BV07IS069', 'Ramesh Bhat', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV07IS072', '2BV07IS072', 'Rashmi Angadi', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV07IS073', '2BV07IS073', 'Ravi Bhaskar', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV07IS074', '2BV07IS074', 'Ravi Shankar', '2008', 'yes', 'Accenture', '3', '2011'),
('2BV07IS075', '2BV07IS075', 'Ravish Vernekar', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV07IS076', '2BV07IS076', 'Reshma Jadhav', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV07IS077', '2BV07IS077', 'Richa Kumari', '2008', 'yes', 'Accenture', '3', '2011'),
('2BV07IS078', '2BV07IS078', 'Ritika Barakol', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV07IS079', '2BV07IS079', 'Rohit Hegde', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV07IS080', '2BV07IS080', 'Rohit Negi', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV07IS082', '2BV07IS082', 'Rudrappa Binjawadagi', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV07IS083', '2BV07IS083', 'Runahee.P.Mundwadkar', '2008', 'yes', 'MindTree', '3.2', '2011'),
('2BV07IS084', '2BV07IS084', 'Saiprakash H', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV07IS086', '2BV07IS086', 'Samrita Kulkarni', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV07IS087', '2BV07IS087', 'Sandeep Katta', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV07IS090', '2BV07IS090', 'Sapna Thakkannawar', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV07IS092', '2BV07IS092', 'Savita Dodamani', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV07IS095', '2BV07IS095', 'Shivalingappa Battur', '2008', 'yes', 'SLK Software', '1.8', '2011'),
('2BV07IS096', '2BV07IS096', 'Shraddha Upadhya', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV07IS097', '2BV07IS097', 'Shreedhar Talikoti', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV07IS099', '2BV07IS099', 'Shruti N S', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV07IS100', '2BV07IS100', 'Shwetha Shetty', '2008', 'yes', 'Accenture', '3', '2011'),
('2BV07IS101', '2BV07IS101', 'Siddhartha Hansraj', '2008', 'yes', 'Accenture', '3', '2011'),
('2BV07IS102', '2BV07IS102', 'Simin Doddamani', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV07IS103', '2BV07IS103', 'Sudha Birde', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV07IS104', '2BV07IS104', 'Supreet IC', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV07IS105', '2BV07IS105', 'Swapna Shetty', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV07IS106', '2BV07IS106', 'Uma K.C', '2008', 'yes', 'MindTree', '3.2', '2011'),
('2BV07IS107', '2BV07IS107', 'V Rao', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV07IS108', '2BV07IS108', 'Vadiraj Kulkarni', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV07IS109', '2BV07IS109', 'Vadiraj Kakhandaki', '2008', 'yes', 'Toshiba Embedded Software India Pvt. Ltd.', '3.5', '2011'),
('2BV07IS110', '2BV07IS110', 'Varad R Patil', '2008', 'yes', 'Accenture', '3', '2011'),
('2BV07IS113', '2BV07IS113', 'Vijayamahantesh Mathapati', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV07IS114', '2BV07IS114', 'Vijaykumar Kubsad', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV07IS115', '2BV07IS115', 'Vinay Grampurohit', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV07IS116', '2BV07IS116', 'Vinay Shetty', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV07IS117', '2BV07IS117', 'Vinaykumar Holeppagol', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV07IS118', '2BV07IS118', 'Vishal Kataruka', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV07IS119', '2BV07IS119', 'Vishwanatha M Kolkar', '2008', 'yes', 'Accenture', '3', '2011'),
('2BV07IS120', '2BV07IS120', 'Yallappa P Barker', '2008', 'yes', 'Accenture', '3', '2011'),
('2BV07IS121', '2BV07IS121', 'Shweta Albal', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV07IS122', '2BV07IS122', 'Satish Gaddi', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV07IS123', '2BV07IS123', 'Shruti S Sardeshpande', '2008', 'yes', 'Accenture', '3', '2011'),
('2BV08IS001', '2BV08IS001', 'Abdul Gafoor M. Nadaf', '2009', 'yes', 'MindTree', '3.2', '2012'),
('2BV08IS002', '2BV08IS002', 'Abhay Kumar Gupta', '2009', 'yes', 'MindTree', '3.2', '2012'),
('2BV08IS003', '2BV08IS003', 'AbhilashG. Kulkarni', '2009', 'yes', 'TCS', '3.16', '2012'),
('2BV08IS004', '2BV08IS004', 'Aadesh A. Pai', '2009', 'yes', 'MindTree', '3.2', '2012'),
('2BV08IS005', '2BV08IS005', 'Akshata G. Bhat', '2009', 'yes', 'TCS', '3.16', '2012'),
('2BV08IS006', '2BV08IS006', 'Akshata A.Hombali', '2009', 'yes', 'iGate Patni', '3.25', '2012'),
('2BV08IS008', '2BV08IS008', 'Aman K. Pathak', '2009', 'yes', 'iGate Patni', '3.25', '2012'),
('2BV08IS009', '2BV08IS009', 'Amita R. Manchanli', '2009', 'yes', 'TCS', '3.16', '2012'),
('2BV08IS012', '2BV08IS012', 'Anirudh R.Desai', '2009', 'yes', 'Unisys Global Services India', '2.25', '2012'),
('2BV08IS016', '2BV08IS016', 'Ashwini R. Samnekar', '2009', 'yes', 'TCS', '3.16', '2012'),
('2BV08IS018', '2BV08IS018', 'Basavaraj Kudagi', '2009', 'yes', 'MindTree', '3.2', '2012'),
('2BV08IS019', '2BV08IS019', 'Basavarajeshwari G. Chincholi', '2009', 'yes', 'TCS', '3.16', '2012'),
('2BV08IS020', '2BV08IS020', 'Bhagyashree M. Deshpande', '2009', 'yes', 'TCS', '3.16', '2012'),
('2BV08IS021', '2BV08IS021', 'Bhagyashree S. Hegde', '2009', 'yes', 'TCS', '3.16', '2012'),
('2BV08IS022', '2BV08IS022', 'Chaya C. Shetty', '2009', 'yes', 'TCS', '3.16', '2012'),
('2BV08IS023', '2BV08IS023', 'Dalveer Singh', '2009', 'yes', 'MindTree', '3.2', '2012'),
('2BV08IS024', '2BV08IS024', 'Deepa G.Patil', '2009', 'yes', 'TCS', '3.16', '2012'),
('2BV08IS026', '2BV08IS026', 'Deepti K. Khamitkar', '2009', 'yes', 'iGate Patni', '3.25', '2012'),
('2BV08IS028', '2BV08IS028', 'Disha R. Bansal', '2009', 'yes', 'TCS', '3.16', '2012'),
('2BV08IS029', '2BV08IS029', 'Divyashree K.S.', '2009', 'yes', 'TCS', '3.16', '2012'),
('2BV08IS031', '2BV08IS031', 'Gaurav Prakash', '2009', 'yes', 'MindTree', '3.2', '2012'),
('2BV08IS032', '2BV08IS032', 'Harshit Raj', '2009', 'yes', 'iGate Patni', '3.25', '2012'),
('2BV08IS034', '2BV08IS034', 'Karan R. Madival', '2009', 'yes', 'TCS', '3.16', '2012'),
('2BV08IS036', '2BV08IS036', 'Kiran Sharma', '2009', 'yes', 'TCS', '3.16', '2012'),
('2BV08IS038', '2BV08IS038', 'Kumar Padmanabham', '2009', 'yes', 'MindTree', '3.2', '2012'),
('2BV08IS039', '2BV08IS039', 'Lavisha V. Mehta', '2009', 'yes', 'MindTree', '3.07', '2012'),
('2BV08IS040', '2BV08IS040', 'Laxman M Myageri', '2009', 'yes', 'MindTree', '3.2', '2012'),
('2BV08IS041', '2BV08IS041', 'Mallappa B. Malagi', '2009', 'yes', 'MindTree', '3.2', '2012'),
('2BV08IS042', '2BV08IS042', 'Mallika N.', '2009', 'yes', 'TCS', '3.16', '2012'),
('2BV08IS043', '2BV08IS043', 'Mandar M. Joshi', '2009', 'yes', 'TCS', '3.16', '2012'),
('2BV08IS044', '2BV08IS044', 'Manjusha D. Nayak', '2009', 'yes', 'TCS', '3.16', '2012'),
('2BV08IS045', '2BV08IS045', 'Megha Inamdar', '2009', 'yes', 'TCS', '3.16', '2012'),
('2BV08IS046', '2BV08IS046', 'Naresh Kumar S. Gunjal', '2009', 'yes', 'TCS', '3.16', '2012'),
('2BV08IS047', '2BV08IS047', 'Navaneet M. Patil', '2009', 'yes', 'TCS', '3.16', '2012'),
('2BV08IS048', '2BV08IS048', 'Naveen R. Saliyan', '2009', 'yes', 'TCS', '3.16', '2012'),
('2BV08IS051', '2BV08IS051', 'Nikita B. Bastian', '2009', 'yes', 'TCS', '3.16', '2012'),
('2BV08IS052', '2BV08IS052', 'Nikita T. Jituri', '2009', 'yes', 'MindTree', '3.2', '2012'),
('2BV08IS053', '2BV08IS053', 'Nilambar A. Singh', '2009', 'yes', 'MindTree', '3.07', '2012'),
('2BV08IS054', '2BV08IS054', 'Niranjan P. Tulajapure', '2009', 'yes', 'TCS', '3.16', '2012'),
('2BV08IS055', '2BV08IS055', 'Niriksha R. Batli', '2009', 'yes', 'Keane', '2.25', '2012'),
('2BV08IS056', '2BV08IS056', 'Nitya P. Navali', '2009', 'yes', 'TCS', '3.16', '2012'),
('2BV08IS057', '2BV08IS057', 'Nivedita A. Revankar', '2009', 'yes', 'TCS', '3.16', '2012'),
('2BV08IS058', '2BV08IS058', 'Nivedita M. Mahale', '2009', 'yes', 'TCS', '3.16', '2012'),
('2BV08IS059', '2BV08IS059', 'P.Akshara Reddy', '2009', 'yes', 'MindTree', '3.2', '2012'),
('2BV08IS061', '2BV08IS061', 'Parvati R. Bhute', '2009', 'yes', 'TCS', '3.16', '2012'),
('2BV08IS065', '2BV08IS065', 'Pradip Kumar Singh', '2009', 'yes', 'MindTree', '3.2', '2012'),
('2BV08IS067', '2BV08IS067', 'Pratima V. Bhat', '2009', 'yes', 'TCS', '3.16', '2012'),
('2BV08IS068', '2BV08IS068', 'Preeti M. Habib', '2009', 'yes', 'MindTree', '3.2', '2012'),
('2BV08IS070', '2BV08IS070', 'Prem Shankar', '2009', 'yes', 'TCS', '3.16', '2012'),
('2BV08IS071', '2BV08IS071', 'Priya R. Nayak', '2009', 'yes', 'TCS', '3.16', '2012'),
('2BV08IS072', '2BV08IS072', 'Priyank S. Chinchakandi', '2009', 'yes', 'TCS', '3.16', '2012'),
('2BV08IS073', '2BV08IS073', 'Priyanka H. Umashankar', '2009', 'yes', 'TCS', '3.16', '2012'),
('2BV08IS074', '2BV08IS074', 'Puja A. Munavalli', '2009', 'yes', 'TCS', '3.16', '2012'),
('2BV08IS075', '2BV08IS075', 'Raghunandan V.Naik', '2009', 'yes', 'TCS', '3.16', '2012'),
('2BV08IS076', '2BV08IS076', 'Rajashree H. Waghamore', '2009', 'yes', 'MindTree', '3.07', '2012'),
('2BV08IS079', '2BV08IS079', 'Regan', '2009', 'yes', 'TCS', '3.16', '2012'),
('2BV08IS080', '2BV08IS080', 'Reshma M. Nadaf', '2009', 'yes', 'TCS', '3.16', '2012'),
('2BV08IS081', '2BV08IS081', 'Rohan Chandra', '2009', 'yes', 'TCS', '3.16', '2012'),
('2BV08IS082', '2BV08IS082', 'Roshan S. Deshpande', '2009', 'yes', 'TCS', '3.16', '2012'),
('2BV08IS083', '2BV08IS083', 'Rudrappa B. Bugati', '2009', 'yes', 'TCS', '3.16', '2012'),
('2BV08IS084', '2BV08IS084', 'Sagar M. Patil', '2009', 'yes', 'MindTree', '3.2', '2012'),
('2BV08IS085', '2BV08IS085', 'Sai P. Bhat', '2009', 'yes', 'TCS', '3.16', '2012'),
('2BV08IS086', '2BV08IS086', 'Sanni Kumar Jha', '2009', 'yes', 'TCS', '3.16', '2012'),
('2BV08IS088', '2BV08IS088', 'Santosh K. Holikatti', '2009', 'yes', 'MindTree', '3.2', '2012'),
('2BV08IS089', '2BV08IS089', 'Seema M.Guggari', '2009', 'yes', 'TCS', '3.16', '2012'),
('2BV08IS094', '2BV08IS094', 'Shreya P. Kampli', '2009', 'yes', 'TCS', '3.16', '2012'),
('2BV08IS096', '2BV08IS096', 'Shruti S. Marihal', '2009', 'yes', 'iGate Patni', '3.25', '2012'),
('2BV08IS097', '2BV08IS097', 'Shruti A. Savadi', '2009', 'yes', 'TCS', '3.16', '2012'),
('2BV08IS099', '2BV08IS099', 'Shubendu Sundram', '2009', 'yes', 'MindTree', '3.2', '2012'),
('2BV08IS100', '2BV08IS100', 'Shweta M. Hiremath', '2009', 'yes', 'KPIT Cummins', '2.8', '2012'),
('2BV08IS101', '2BV08IS101', 'Shweta R. Sankolli', '2009', 'yes', 'TCS', '3.16', '2012'),
('2BV08IS102', '2BV08IS102', 'Simant', '2009', 'yes', 'Span Infotech India Pvt. Ltd.', '2.55', '2012'),
('2BV08IS103', '2BV08IS103', 'Somanath A. Sukhasare', '2009', 'yes', 'Span Infotech India Pvt. Ltd.', '2.55', '2012'),
('2BV08IS104  ', '2BV08IS104  ', 'Sourabh Kumar', '2009', 'yes', 'MindTree', '3.2', '2012'),
('2BV08IS106', '2BV08IS106', 'Suhail I. Kotwal', '2009', 'yes', 'TCS', '3.16', '2012'),
('2BV08IS108', '2BV08IS108', 'Supreet R. Totagi', '2009', 'yes', 'TCS', '3.16', '2012'),
('2BV08IS109', '2BV08IS109', 'Supriya G. Kulkarni', '2009', 'yes', 'TCS', '3.16', '2012'),
('2BV08IS110', '2BV08IS110', 'Swapaneel M. Utture', '2009', 'yes', 'TCS', '3.16', '2012'),
('2BV08IS111', '2BV08IS111', 'Swetha M.', '2009', 'yes', 'TCS', '3.16', '2012'),
('2BV08IS112', '2BV08IS112', 'Tanay Shresth', '2009', 'yes', 'MindTree', '3.2', '2012'),
('2BV08IS114', '2BV08IS114', 'Vadiraj G. Pothanakatti', '2009', 'yes', 'TCS', '3.16', '2012'),
('2BV08IS115', '2BV08IS115', 'Varun G. Joshi', '2009', 'yes', 'TCS', '3.16', '2012'),
('2BV08IS116', '2BV08IS116', 'Vijaykumar M Muddebihal', '2009', 'yes', 'TCS', '3.16', '2012'),
('2BV08IS119', '2BV08IS119', 'Vivek R.', '2009', 'yes', 'TCS', '3.16', '2012'),
('2BV08IS120', '2BV08IS120', 'Yaseen M. Mirajkar', '2009', 'yes', 'TCS', '3.16', '2012'),
('2BV08IS121', '2BV08IS121', 'Siddeshwar S. Vaddatti', '2009', 'yes', 'TCS', '3.16', '2012'),
('2BV08IS123', '2BV08IS123', 'Chaitanya M Gauri', '2009', 'yes', 'MindTree', '3.2', '2012'),
('2BV08IS124', '2BV08IS124', 'Pooja M Kulinavar', '2009', 'yes', 'MindTree', '3.2', '2012'),
('2BV08IS125', '2BV08IS125', 'Suhani S. Ariga', '2009', 'yes', 'MindTree', '3.2', '2012'),
('2BV08IS401', '2BV08IS401', 'Anuradha Bangalore', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV08IS403', '2BV08IS403', 'Manjunath.S.Ambiger', '2008', 'yes', 'MindTree', '3.2', '2011'),
('2BV08IS404', '2BV08IS404', 'Nandish Jolad', '2008', 'yes', 'Toshiba Embedded Software India Pvt. Ltd.', '3.5', '2011'),
('2BV08IS405', '2BV08IS405', 'Prashantkumar Poojari', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV08IS406', '2BV08IS406', 'Rohit Iti', '2008', 'yes', 'KPIT Cummin', '2.8', '2011'),
('2BV08IS407', '2BV08IS407', 'Sanaafrin Reshamwale', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV08IS409', '2BV08IS409', 'Sudheer P ', '2008', 'yes', 'Accenture', '3', '2011'),
('2BV08IS410', '2BV08IS410', 'Tulsa Dalbanjan', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BV08IS411', '2BV08IS411', 'Vijaykumar S.Gangavati', '2008', 'yes', 'MindTree', '3.2', '2011'),
('2BV09IS003', '2BV09IS003', 'Abhishek Ranjan', '2010', 'yes', 'Span Infotech India Pvt. Ltd.', '2.5', '2013'),
('2BV09IS007', '2BV09IS007', 'Akshata S.H.', '2010', 'yes', 'TCS', '3.16', '2013'),
('2BV09IS008', '2BV09IS008', 'Akshata S.Hebbal', '2010', 'yes', 'Akamai', '6.7', '2013'),
('2BV09IS014', '2BV09IS014', 'Ankita Nargundkar', '2010', 'yes', 'TCS', '3.16', '2013'),
('2BV09IS016', '2BV09IS016', 'Anusha S. Bhandari', '2010', 'yes', 'Toshiba', '4', '2013'),
('2BV09IS017', '2BV09IS017', 'Archana Chandrabandi', '2010', 'yes', 'TCS', '3.16', '2013'),
('2BV09IS018', '2BV09IS018', 'Arpit Jha', '2010', 'yes', 'Span Infotech India Pvt. Ltd.', '2.5', '2013'),
('2BV09IS021', '2BV09IS021', 'Ashwini N. Nayak', '2010', 'yes', 'TCS', '3.16', '2013'),
('2BV09IS022', '2BV09IS022', 'Ashiwini S.Shirasangi', '2010', 'yes', 'TCS', '3.16', '2013'),
('2BV09IS023', '2BV09IS023', 'Avinash S. Bengeri', '2010', 'yes', 'TCS', '3.16', '2013'),
('2BV09IS025', '2BV09IS025', 'C.Pavan', '2010', 'yes', 'Sony', '4.25', '2013'),
('2BV09IS029', '2BV09IS029', 'Devaraj M. Nayak', '2010', 'yes', 'TCS', '3.16', '2013'),
('2BV09IS030', '2BV09IS030', 'Devendra B.Hupri', '2010', 'yes', 'TCS', '3.16', '2013'),
('2BV09IS031', '2BV09IS031', 'Dhriti D. Mahajan', '2010', 'yes', 'TCS', '3.16', '2013'),
('2BV09IS042', '2BV09IS042', 'M.S.Divyabharathi', '2010', 'yes', 'TCS', '3.16', '2013'),
('2BV09IS043', '2BV09IS043', 'Sanjana M.S.', '2010', 'yes', 'Robert Bosch', '3.6', '2013'),
('2BV09IS044', '2BV09IS044', 'Mahabaleshwargoud S.Patil', '2010', 'yes', 'TCS', '3.16', '2013'),
('2BV09IS049', '2BV09IS049', 'Megha V.Katti', '2010', 'yes', 'TCS', '3.16', '2013'),
('2BV09IS052', '2BV09IS052', 'Menaka N. Saunshi', '2010', 'yes', 'TCS', '3.16', '2013'),
('2BV09IS054', '2BV09IS054', 'Mritunjay', '2010', 'yes', 'MindTree', '3.2', '2013'),
('2BV09IS058', '2BV09IS058', 'Nitin R.Shenoy', '2010', 'yes', 'MindTree', '3.2', '2013'),
('2BV09IS059', '2BV09IS059', 'Nivedita Bhat', '2010', 'yes', 'TCS', '3.16', '2013'),
('2BV09IS060', '2BV09IS060', 'Pavan P. Gandamali', '2010', 'yes', 'Subex', '4.75', '2013'),
('2BV09IS062', '2BV09IS062', 'Pavankumar B L', '2010', 'yes', 'Informatica', '5.8', '2013'),
('2BV09IS065', '2BV09IS065', 'Pooja S. Biradar', '2010', 'yes', 'TCS', '3.16', '2013'),
('2BV09IS074', '2BV09IS074', 'Priyansu Pratik', '2010', 'yes', 'MindTree', '3.2', '2013'),
('2BV09IS076', '2BV09IS076', 'Priyanka K Dambal', '2010', 'yes', 'TCS', '3.16', '2013'),
('2BV09IS077', '2BV09IS077', 'Priyanka S. Awaraddi', '2010', 'yes', 'Subex', '4.75', '2013'),
('2BV09IS079', '2BV09IS079', 'Raghvendra Pastay', '2010', 'yes', 'Informatica', '5.8', '2013'),
('2BV09IS083', '2BV09IS083', 'Renuka D.Waghamare', '2010', 'yes', 'MindTree', '3.2', '2013'),
('2BV09IS085', '2BV09IS085', 'Suraj S.', '2010', 'yes', 'TCS', '3.16', '2013'),
('2BV09IS086', '2BV09IS086', 'Sachin S. Shetty', '2010', 'yes', 'Subex', '4.75', '2013'),
('2BV09IS088', '2BV09IS088', 'Salil Ranjan', '2010', 'yes', 'TCS', '3.16', '2013'),
('2BV09IS093', '2BV09IS093', 'Saroja Hampli', '2010', 'yes', 'TCS', '3.16', '2013'),
('2BV09IS095', '2BV09IS095', 'Shilpa S. Sollapur', '2010', 'yes', 'TCS', '3.16', '2013'),
('2BV09IS096', '2BV09IS096', 'Shridhar V.Kalagi', '2010', 'yes', 'TCS', '3.16', '2013'),
('2BV09IS098', '2BV09IS098', 'Shruti V.Khode', '2010', 'yes', 'TCS', '3.16', '2013'),
('2BV09IS103', '2BV09IS103', 'Sovan Keshri', '2010', 'yes', 'Span Infotech India Pvt. Ltd.', '2.5', '2013'),
('2BV09IS104', '2BV09IS104', 'Sudheer B.Bidarahalli', '2010', 'yes', 'TCS', '3.16', '2013'),
('2BV09IS108', '2BV09IS108', 'Swathi J. Shetty', '2010', 'yes', 'TCS', '3.16', '2013'),
('2BV09IS109', '2BV09IS109', 'Tanuja Y. Sannagoudar', '2010', 'yes', 'TCS', '3.16', '2013'),
('2BV09IS110', '2BV09IS110', 'Umair S. Tarafdar', '2010', 'yes', 'TCS', '3.16', '2013'),
('2BV09IS111', '2BV09IS111', 'Varsga Shetty', '2010', 'yes', 'TCS', '3.16', '2013'),
('2BV09IS112', '2BV09IS112', 'Yashodha Kittur', '2010', 'yes', 'TCS', '3.16', '2013'),
('2BV09IS119', '2BV09IS119', 'Zohra D. Nadaf', '2010', 'yes', 'TCS', '3.16', '2013'),
('2BV09IS120', '2BV09IS120', 'Basavaraj G.Ganagi', '2010', 'yes', 'MindTree', '3.2', '2013'),
('2BV09IS121', '2BV09IS121', 'Navya R. Bailkeri', '2010', 'yes', 'TCS', '3.16', '2013'),
('2BV09IS122', '2BV09IS122', 'Ruchika R.Jain', '2010', 'yes', 'TCS', '3.16', '2013'),
('2BV09IS123', '2BV09IS123', 'Deepa C.Huded', '2010', 'yes', 'MindTree', '3.2', '2013'),
('2BV09IS124', '2BV09IS124', 'Kumar N. Sugnani', '2010', 'yes', 'TCS', '3.16', '2013'),
('2BV09IS125', '2BV09IS125', 'Sudhanva Kotabagi', '2010', 'yes', 'TCS', '3.16', '2013'),
('2BV09IS126', '2BV09IS126', 'Abhishek Raichur', '2010', 'yes', 'TCS', '3.16', '2013'),
('2BV09IS128', '2BV09IS128', 'Rakesh M. Lagare', '2010', 'yes', 'TCS', '3.16', '2013'),
('2BV09IS400', '2BV09IS400', 'Abhulazeem Yarzari', '2009', 'yes', 'MindTree', '3.2', '2012'),
('2BV09IS402', '2BV09IS402', 'Annapurna G. Akki', '2009', 'yes', 'MindTree', '3.2', '2012'),
('2BV09IS403', '2BV09IS403', 'Deepak N. Halivan', '2009', 'yes', 'TCS', '3.16', '2012'),
('2BV09IS404', '2BV09IS404', 'Deepali S.Patil', '2009', 'yes', 'Akamai', '6.91', '2012'),
('2BV09IS406', '2BV09IS406', 'Komal V. Jadhav', '2009', 'yes', 'TCS', '3.16', '2012'),
('2BV09IS408', '2BV09IS408', 'Mouna M. Naravani', '2009', 'yes', 'MindTree', '3.2', '2012'),
('2BV09IS409', '2BV09IS409', 'Nitin P. Jadhav', '2009', 'yes', 'MindTree', '3.2', '2012'),
('2BV09IS410', '2BV09IS410', 'Pooja B. Purohit', '2009', 'yes', 'MindTree', '3.2', '2012'),
('2BV09IS411', '2BV09IS411', 'Pooja V. Mohite', '2009', 'yes', 'TCS', '3.16', '2012'),
('2BV09IS417', '2BV09IS417', 'Vithal A. Inamdar', '2009', 'yes', 'TCS', '3.16', '2012'),
('2BV10IS403', '2BV10IS403', 'Girish C. Sanenahalli', '2010', 'yes', 'Toshiba', '4', '2013'),
('2bv11is401', '2bv11is401', 'ashok', '2011', 'yes', 'TCS', '2', '2014'),
('2bv11is402', '2bv11is402', 'arun', '2011', 'yes', 'TCS', '2', '2014'),
('2bv11is403', '2bv11is403', 'dileep', '2011', 'yes', 'TCS', '2', '2014'),
('2bv11is417', '2bv11is4171', 'ritesh', '2011', 'no', NULL, '0', '2011'),
('2bv11is418', 'cf3198ad7c53', 'satish', '2011', 'yes', 'Wipro', '2', '2012'),
('2BV129004', '2BV129004', 'Anoop Parvatimath', '2008', 'yes', 'TCS', '3.16', '2011'),
('2BVO8IS036', '2BVO8IS036', 'Kiran Sharma', '2009', 'yes', 'MindTree', '3.2', '2012');
